<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Substitua pelo seu usuário
define('DB_PASS', ''); // Substitua pela sua senha
define('DB_NAME', 'nave');
